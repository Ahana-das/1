package com.cap.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cap.entities.Insurance;


@Repository		
public interface InsuranceDao extends JpaRepository<Insurance,Integer> {
	
	@Query("select be from Insurance be where be.purchaseYear =?1")
	Optional<List<Insurance>> viewAll(@Param("c") int purchaseYear);

}
