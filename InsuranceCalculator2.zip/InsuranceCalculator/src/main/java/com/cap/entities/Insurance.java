package com.cap.entities;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="insurance3")
public class Insurance {
	
	@Id
	@GeneratedValue
	private int id;
	private String vehicleModel;
	private double onRoadPrice;
	private int purchaseYear;
	private double insuranceAmount;
	private Date expDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getVehicleModel() {
		return vehicleModel;
	}
	public void setVehicleModel(String vehicleModel) {
		this.vehicleModel = vehicleModel;
	}
	
	public double getOnRoadPrice() {
		return onRoadPrice;
	}
	public void setOnRoadPrice(double onRoadPrice) {
		this.onRoadPrice = onRoadPrice;
	}
	public int getPurchaseYear() {
		return purchaseYear;
	}
	public void setPurchaseYear(int purchaseYear) {
		this.purchaseYear = purchaseYear;
	}
	public double getInsuranceAmount() {
		return insuranceAmount;
	}
	public void setInsuranceAmount(double insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}
	public Date getExpDate() {
		return expDate;
	}
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
	@Override
	public String toString() {
		return "Insurance [id=" + id + ", vehicleModel=" + vehicleModel + ", onRoadPrice=" + onRoadPrice
				+ ", purchaseYear=" + purchaseYear + ", insuranceAmount=" + insuranceAmount + ", expDate=" + expDate
				+ "]";
	}
	
	
	

}
