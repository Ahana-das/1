package com.cap.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.dao.InsuranceDao;
import com.cap.entities.Insurance;
@Service
public class InsuranceService implements InsuranceServiceI {
	@Autowired
	InsuranceDao dao;
	
	@Override
	public Insurance calculateInsurance(Insurance bean) {
		double Price = bean.getOnRoadPrice();
		int purchaseYear = bean.getPurchaseYear();
		
		double amount = Price - (0.05 * (2019-purchaseYear));
		double insuranceAmount = (amount * (2.5)) / 100;
		bean.setInsuranceAmount(insuranceAmount);
	
		
		return bean;
	}


	@Override
	public List<Insurance> addInsurance(Insurance ins) {
		ins = calculateInsurance(ins);
		

		Calendar cal=Calendar.getInstance();
		
		cal.add(Calendar.YEAR, 1);
		Date today=cal.getTime();
		ins.setExpDate(today);
		dao.save(ins);
		return dao.findAll();
	}


	@Override
	public Insurance findInsuranceById(int id) {
		return dao.findById(id).get();
	}


	@Override
	public List<Insurance> viewAll() {
		return dao.findAll();
	}


	@Override
	public Insurance viewInsuranceById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id).get();
	}


	@Override
	public List<Insurance> updateInsurance(Integer id, Insurance ins) {
		// TODO Auto-generated method stub
		
		Optional<Insurance> e=dao.findById(id);
		Insurance e1=e.get();
		
		//e1.setId(ins.getId());
		e1.setInsuranceAmount(ins.getInsuranceAmount());
		e1.setOnRoadPrice(ins.getOnRoadPrice());
		e1.setPurchaseYear(ins.getPurchaseYear());
		e1.setVehicleModel(ins.getVehicleModel());
		e1.setExpDate(ins.getExpDate());
		
		dao.save(e1);
		
		return dao.findAll();
	}


	@Override
	public void deleteInsurance(Integer eid) {
		dao.deleteById(eid);
		
	}


	@Override
	public List<Insurance> findAll() {
		
		return dao.findAll();
	}
	
	
	
	


	


	
	
}
