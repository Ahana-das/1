package com.cap.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cap.entities.Insurance;
import com.cap.service.InsuranceServiceI;

@RestController
@RequestMapping("/Insurance")
public class RestControllerUi {
	 @Autowired
	InsuranceServiceI service;
	 
	 @PostMapping("/createAccount")
	    public List<Insurance> addInsurance(@RequestBody Insurance ins)
	    {
	        return service.addInsurance(ins);
	        
	    }
	 
	 @GetMapping(path = "/find/{id}")
		public Insurance findInsuranceById(@PathVariable Integer id) {
			return service.findInsuranceById(id);
		}
	 
	 @GetMapping(path = "/findAll")
		public List<Insurance> findAll() {
			return service.findAll();
		}
	 
	 @GetMapping(path = "/viewAll")
	 public List<Insurance> viewAll() {
		return service.viewAll();
		 
	 }


	 @GetMapping(path = "/viewById/{id}")
		public Insurance viewInsuranceById(@PathVariable Integer id) {
			return service.viewInsuranceById(id);
		}
	 
	 @PutMapping("/updateInsurance/{id}")
		public List<Insurance> updateInsurance(@PathVariable Integer id,@RequestBody Insurance ins) {
			System.out.println(id);
			System.out.println(ins.getVehicleModel());
			return service.updateInsurance(id, ins);
		}
	 
	 @DeleteMapping("/deleteInsurance/{id}")
	  public ResponseEntity<String> deleteInsurance(@PathVariable int id)
	   
   {
       service.deleteInsurance(id);
       return new ResponseEntity<String>("Insurance id="+id+" deleted",HttpStatus.OK);
      
   }
	 
	 @GetMapping(path = "/viewAll/{purchaseyear}")
	 public Optional<List<Insurance>> viewAll(@PathVariable int purchaseyear) {
		return service.viewAll(purchaseyear);
		 
	 }

	    

}
