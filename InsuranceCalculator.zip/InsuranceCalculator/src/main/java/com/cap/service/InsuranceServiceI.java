package com.cap.service;

import java.util.List;

import com.cap.entities.Insurance;

public interface InsuranceServiceI {
	
	public Insurance calculateInsurance(Insurance bean);
	public List<Insurance> addInsurance(Insurance ins);
	
	public Insurance findInsuranceById(int id);
	
	public List<Insurance> viewAll();
	
	public Insurance viewInsuranceById(int id);
	
	public List<Insurance> updateInsurance(Integer id,Insurance ins);
	
	public void deleteInsurance(Integer eid);
	public List<Insurance> findAll();
	
	

}
